---
name: Question inquiry
about: Ask a question about this project
title: ''
labels: question, help wanted 
assignees: panjf2000

---

**Please fill out the following system information before opening an issue:**
 - OS (e.g. Ubuntu 18.04):
 - Go version (e.g. Go 1.13):
 - gnet version (e.g. v1.0.0):

**What is your question about gnet?**
Please describe your question meticulously.
