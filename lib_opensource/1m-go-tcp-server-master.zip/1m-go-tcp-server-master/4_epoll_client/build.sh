#!/bin/bash

go build --tags "static netgo" -o client  .