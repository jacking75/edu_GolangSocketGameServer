#!/bin/bash
go tool pprof http://localhost:6060/debug/pprof/goroutine
